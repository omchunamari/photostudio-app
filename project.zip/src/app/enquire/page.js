"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { getEnquiryFormConfig } from "@/lib/firebase/enquiryForm";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CheckCircle2, Loader2 } from "lucide-react";

// A thin strip of evenly-spaced perforations — a small nod to film sprocket
// holes, in keeping with "The Rolling Stories" name. Pure CSS, no assets.
function FilmStrip({ tone = "dark" }) {
  const hole = tone === "dark" ? "rgba(250,248,244,0.5)" : "rgba(28,27,25,0.18)";
  return (
    <div
      className="h-[6px] w-full"
      style={{
        backgroundImage: `repeating-linear-gradient(to right, ${hole} 0, ${hole} 5px, transparent 5px, transparent 16px)`,
      }}
      aria-hidden="true"
    />
  );
}

// Scrolling marquee band — the "rolling" part of the theme. Pure CSS
// keyframe animation defined inline so this stays a single file.
function RollingBand() {
  const words = ["Weddings", "Films", "Pre-Wedding", "Portraits", "Events", "Stories"];
  const line = [...words, ...words, ...words];
  return (
    <div className="overflow-hidden bg-[var(--accent)] py-1.5">
      <style>{`
        @keyframes trs-marquee {
          from { transform: translateX(0); }
          to { transform: translateX(-33.333%); }
        }
        .trs-marquee-track {
          animation: trs-marquee 26s linear infinite;
        }
      `}</style>
      <div className="trs-marquee-track flex w-max items-center gap-2.5 whitespace-nowrap">
        {line.map((w, i) => (
          <span key={i} className="flex items-center gap-2.5 text-[10px] font-medium tracking-[0.18em] text-[var(--accent-foreground)] uppercase">
            {w}
            <span className="text-[var(--accent-foreground)]/50">✦</span>
          </span>
        ))}
      </div>
    </div>
  );
}

function FieldInput({ field, value, onChange }) {
  const id = `field-${field.key}`;
  if (field.type === "textarea") {
    return (
      <Textarea
        id={id}
        rows={4}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder="Your answer"
      />
    );
  }
  if (field.type === "select") {
    return (
      <Select value={value || ""} onValueChange={onChange}>
        <SelectTrigger id={id} className="w-full">
          <SelectValue placeholder="Choose" />
        </SelectTrigger>
        <SelectContent>
          {(field.options || []).map((opt) => (
            <SelectItem key={opt} value={opt}>
              {opt}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    );
  }
  const inputType =
    field.type === "date" ? "date" : field.type === "number" ? "number" : field.type === "email" ? "email" : field.type === "tel" ? "tel" : "text";
  return (
    <Input
      id={id}
      type={inputType}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={field.type === "date" ? undefined : "Your answer"}
    />
  );
}

export default function PublicEnquiryFormPage() {
  const [config, setConfig] = useState(null);
  const [loading, setLoading] = useState(true);
  const [values, setValues] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    getEnquiryFormConfig().then((cfg) => {
      setConfig(cfg);
      document.title = `${cfg.title || "Enquiry Form"} · The Rolling Stories`;
      setLoading(false);
    });
  }, []);

  function update(key, val) {
    setValues((v) => ({ ...v, [key]: val }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");

    const missing = (config.fields || []).filter(
      (f) => f.required && !String(values[f.key] || "").trim()
    );
    if (missing.length) {
      setError(`Please fill in: ${missing.map((f) => f.label).join(", ")}`);
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/leads/public-submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ values, hp: values._hp || "" }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Something went wrong. Please try again.");
        return;
      }
      setSubmitted(true);
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[var(--background)]">
        <Loader2 className="h-6 w-6 animate-spin text-[var(--muted-foreground)]" />
      </div>
    );
  }

  if (submitted) {
    return (
      <div className="min-h-screen bg-[var(--background)]">
        <div className="bg-[var(--primary)]">
          <div className="flex flex-col items-center gap-2 px-6 py-6">
            <Image src="/logo-mark.png" alt="" width={32} height={32} className="h-8 w-8 object-contain invert" />
          </div>
          <FilmStrip tone="dark" />
        </div>
        <RollingBand />

        <div className="flex items-center justify-center px-4 py-16">
          <div className="w-full max-w-md rounded-lg border border-[var(--border)] bg-[var(--card)] p-8 text-center shadow-sm">
            <CheckCircle2 className="mx-auto mb-4 h-10 w-10 text-[var(--success)]" />
            <h1 className="mb-2 font-heading text-2xl font-semibold text-[var(--foreground)]">
              Thank You
            </h1>
            <p className="text-sm text-[var(--muted-foreground)]">
              Your story starts here. We&rsquo;ve received your enquiry and will reach out soon.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--background)]">
      {/* Hero */}
      <div className="bg-[var(--primary)]">
        <div className="flex flex-col items-center gap-2 px-6 py-6 text-center sm:py-7">
          <Image
            src="/logo-light.png"
            alt="The Rolling Stories"
            width={80}
            height={64}
            className="h-9 w-auto object-contain opacity-90 sm:h-10"
            priority
          />
          <h1 className="font-heading text-lg font-semibold italic text-[var(--primary-foreground)] sm:text-xl">
            {config.title}
          </h1>
          {config.subtitle && (
            <p className="mx-auto max-w-sm text-xs text-[var(--primary-foreground)]/60">
              {config.subtitle}
            </p>
          )}
        </div>
        <FilmStrip tone="dark" />
      </div>
      <RollingBand />

      {/* Form */}
      <div className="px-3 py-8 sm:px-4 sm:py-10">
        <div className="mx-auto max-w-xl">
          <form onSubmit={handleSubmit} className="flex flex-col gap-3">
            <div className="rounded-lg border border-[var(--border)] bg-[var(--card)] px-4 py-2.5 text-xs text-[var(--destructive)] shadow-sm sm:px-5">
              * Indicates required question
            </div>

            {/* Honeypot — hidden from real visitors, invisible to screen readers */}
            <input
              type="text"
              name="_hp"
              value={values._hp || ""}
              onChange={(e) => update("_hp", e.target.value)}
              className="hidden"
              tabIndex={-1}
              autoComplete="off"
              aria-hidden="true"
            />

            {(config.fields || []).map((field) => (
              <div
                key={field.id}
                className="rounded-lg border border-[var(--border)] bg-[var(--card)] p-4 shadow-sm sm:p-5"
              >
                <Label htmlFor={`field-${field.key}`} className="mb-3 block text-sm font-medium text-[var(--foreground)]">
                  {field.label}
                  {field.required && <span className="ml-0.5 text-[var(--destructive)]">*</span>}
                </Label>
                <FieldInput
                  field={field}
                  value={values[field.key] || ""}
                  onChange={(v) => update(field.key, v)}
                />
              </div>
            ))}

            {error && (
              <p className="rounded-md bg-[var(--destructive)]/10 p-3 text-sm text-[var(--destructive)]">
                {error}
              </p>
            )}

            <Button type="submit" disabled={submitting} className="mt-1 w-full sm:w-fit">
              {submitting ? "Submitting..." : "Submit"}
            </Button>
          </form>

          <p className="mt-8 text-center text-xs tracking-wide text-[var(--muted-foreground)]">
            The Rolling Stories
          </p>
        </div>
      </div>
    </div>
  );
}